// https://www.restapitutorial.com/httpstatuscodes.html

document.getElementsByClassName('span12')[1].childNodes[3].id = 'para';

new HoverResources().wrapText(document.getElementById('para'), 'This', "My message 1");
new HoverResources().wrapText(document.getElementById('para'), 'page', "My message 2");
new HoverResources().wrapText(document.getElementById('para'), 'is', "My message 3");
new HoverResources().wrapText(document.getElementById('para'), 'created', "My message 4");
new HoverResources().wrapText(document.getElementById('para'), 'from', "My message 5");
new HoverResources().wrapText(document.getElementById('para'), 'HTTP', "My message 6");
new HoverResources().wrapText(document.getElementById('para'), 'status', "My message 7");
new HoverResources().wrapText(document.getElementById('para'), 'code', "My message 8");
new HoverResources().wrapText(document.getElementById('para'), 'information', "My message 9");
new HoverResources().wrapText(document.getElementById('para'), 'found', "My message 10");
new HoverResources().wrapText(document.getElementById('para'), 'at', "My message 11");
new HoverResources().wrapText(document.getElementById('para'), 'ietf.org', "My message 12");
new HoverResources().wrapText(document.getElementById('para'), 'and', "My message 13");
new HoverResources().wrapText(document.getElementById('para'), 'Wikipedia', "My message 14");
new HoverResources().wrapText(document.getElementById('para'), 'Click', "My message 15");
new HoverResources().wrapText(document.getElementById('para'), 'on', "My message 16");
new HoverResources().wrapText(document.getElementById('para'), 'the', "My message 17");
new HoverResources().wrapText(document.getElementById('para'), 'category heading', "My message 18");
new HoverResources().wrapText(document.getElementById('para'), 'or', "My message 20");
new HoverResources().wrapText(document.getElementById('para'), 'the', "My message 21");
new HoverResources().wrapText(document.getElementById('para'), 'status', "My message 22");
new HoverResources().wrapText(document.getElementById('para'), 'code', "My message 23");
new HoverResources().wrapText(document.getElementById('para'), 'link', "My message 24");
new HoverResources().wrapText(document.getElementById('para'), 'to', "My message 25");
new HoverResources().wrapText(document.getElementById('para'), 'read', "My message 26");
new HoverResources().wrapText(document.getElementById('para'), 'more', "My message 27");
